#!/usr/bin/env bash
set -e
echo "Restoring..."
dotnet restore
echo "Building..."
dotnet build --configuration Release
echo "Running tests..."
dotnet test --no-build --verbosity normal
