using Microsoft.AspNetCore.Mvc;
using AspNetAlgorithmicAssessment.Models;

namespace AspNetAlgorithmicAssessment.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WordFrequencyController : ControllerBase
{
    // POST api/wordfrequency/word-frequency
    [HttpPost]
    [Route("word-frequency")]
    public IActionResult GetWordFrequency([FromBody] WordFrequencyRequest req)
    {
        // TODO: Implement word frequency logic (case-insensitive, ignore punctuation)
        // Return: Ok(new { frequencies = new [] { new { word = "the", count = 2 }, ... } })
        return Ok(new { frequencies = new object[0] });
    }
}
