using Microsoft.AspNetCore.Mvc;

namespace AspNetAlgorithmicAssessment.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FibonacciController : ControllerBase
{
    // GET api/fibonacci/sum/{n}
    [HttpGet("sum/{n}")]
    public IActionResult GetFibonacciSum(int n)
    {
        // TODO: Implement the Fibonacci sum logic.
        // Return: Ok(new { sum = <int> });
        // Note: Fibonacci series here starts with 0 as F(1) = 0, F(2) = 1
        return Ok(new { sum = 0 });
    }
}
