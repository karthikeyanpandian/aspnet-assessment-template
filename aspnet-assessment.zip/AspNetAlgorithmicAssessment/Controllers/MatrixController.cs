using Microsoft.AspNetCore.Mvc;
using AspNetAlgorithmicAssessment.Models;

namespace AspNetAlgorithmicAssessment.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MatrixController : ControllerBase
{
    // POST api/matrix/diagonal-difference
    [HttpPost("diagonal-difference")]
    public IActionResult DiagonalDifference([FromBody] MatrixRequest req)
    {
        // TODO: Compute absolute difference between primary and secondary diagonal sums.
        // Return: Ok(new { difference = <int> });
        return Ok(new { difference = 0 });
    }
}
