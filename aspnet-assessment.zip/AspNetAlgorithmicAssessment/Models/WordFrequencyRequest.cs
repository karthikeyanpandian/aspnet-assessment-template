namespace AspNetAlgorithmicAssessment.Models;

public class WordFrequencyRequest
{
    public string? Sentence { get; set; }
}
