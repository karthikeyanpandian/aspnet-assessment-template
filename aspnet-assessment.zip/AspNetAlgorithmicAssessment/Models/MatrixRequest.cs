namespace AspNetAlgorithmicAssessment.Models;

public class MatrixRequest
{
    // Represent matrix as array of int arrays (rows)
    public int[][]? Matrix { get; set; }
}
