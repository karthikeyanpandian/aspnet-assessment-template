# ASP.NET Algorithmic Assessment Template (.NET 6)

This repository is a ready template for giving algorithmic ASP.NET coding assessments
to candidates. It contains 3 tasks (Fibonacci Sum, Word Frequency, Matrix Diagonal Difference)
as ASP.NET Core controllers and an xUnit test project with multiple test cases for automatic validation.

## What is included
- `AspNetAlgorithmicAssessment/` - ASP.NET Core Web API project (stubs for controllers)
- `AspNetAlgorithmicAssessment.Tests/` - xUnit tests that validate candidate implementations
- `.github/workflows/dotnet.yml` - GitHub Actions workflow to auto run tests on push
- `README.md` - this file

## How to use (quick start)
1. Download and unzip the project.
2. Make sure you have .NET 6 SDK installed: https://dotnet.microsoft.com/en-us/download/dotnet/6.0
3. From the repository root, run:
    ```bash
    dotnet restore
    dotnet build
    dotnet test
    ```
4. The tests will fail until the candidate implements the TODOs in the controllers.

## Tasks (for the candidate)
1. **Fibonacci Sum** - Implement `GET /api/fibonacci/sum/{n}` in `FibonacciController.cs`.
   - It should return JSON: `{ "sum": <int> }` where sum is the sum of first `n` Fibonacci numbers.
   - Series definition for this task: F(1) = 0, F(2) = 1, F(3) = 1, ...

2. **Word Frequency** - Implement `POST /api/wordfrequency/word-frequency` in `WordFrequencyController.cs`.
   - Request body: `{ "sentence": "..." }`
   - Response: `{ "frequencies": [ { "word": "the", "count": 3 }, ... ] }`
   - Requirements: case-insensitive, ignore punctuation, sort by count descending then by word ascending.

3. **Matrix Diagonal Difference** - Implement `POST /api/matrix/diagonal-difference` in `MatrixController.cs`.
   - Request body: `{ "matrix": [[...],[...],...] }`
   - Response: `{ "difference": <int> }` where difference = abs(sum(primary diagonal) - sum(secondary diagonal))

## How to distribute to candidates
- **Recommended**: Use [GitHub Classroom](https://classroom.github.com/) and the template repo.
  - Create an assignment using this repo as the template. Students get private repos pre-filled with the template.
  - Set a due date to enforce the 60-minute limit.
- **Alternate**: Ask candidates to fork this repo and submit a Pull Request / push to their fork.

## Scoring & Evaluation
- Tests are the source of truth. All test cases are in the `AspNetAlgorithmicAssessment.Tests` project.
- You can count passed tests or use weighted scoring per task.

## Notes for admins
- The project intentionally contains TODOs in controllers. The tests call those controllers directly,
  so candidates can implement logic without changing test structure.
- If you need, you can expand the testcases in the `AspNetAlgorithmicAssessment.Tests` folder to add more edge cases.

---
Good luck with your hiring!
