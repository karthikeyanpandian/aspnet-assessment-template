using Xunit;
using AspNetAlgorithmicAssessment.Controllers;
using AspNetAlgorithmicAssessment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Linq;

public class WordFrequencyTests
{
    [Fact]
    public void WordFrequency_BasicSentence()
    {
        var controller = new WordFrequencyController();
        var req = new WordFrequencyRequest { Sentence = "the quick brown fox the quick" };
        var result = controller.GetWordFrequency(req) as OkObjectResult;
        Assert.NotNull(result);
        var json = JObject.FromObject(result.Value);
        var freqs = json["frequencies"].ToObject<System.Collections.Generic.List<JObject>>();
        Assert.Equal("the", (string)freqs[0]["word"]);
        Assert.Equal(2, (int)freqs[0]["count"]);
    }

    [Fact]
    public void WordFrequency_PunctuationAndCase()
    {
        var controller = new WordFrequencyController();
        var req = new WordFrequencyRequest { Sentence = "Hello, hello! HELLO? world." };
        var result = controller.GetWordFrequency(req) as OkObjectResult;
        Assert.NotNull(result);
        var json = JObject.FromObject(result.Value);
        var freqs = json["frequencies"].ToObject<System.Collections.Generic.List<JObject>>();
        Assert.Equal("hello", (string)freqs[0]["word"]);
        Assert.Equal(3, (int)freqs[0]["count"]);
        Assert.Equal("world", (string)freqs[1]["word"]);
    }
}
