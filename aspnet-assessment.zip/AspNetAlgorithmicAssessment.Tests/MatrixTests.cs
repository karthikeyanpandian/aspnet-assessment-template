using Xunit;
using AspNetAlgorithmicAssessment.Controllers;
using AspNetAlgorithmicAssessment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

public class MatrixTests
{
    [Fact]
    public void Matrix_DiagonalDifference_Sample()
    {
        var controller = new MatrixController();
        var req = new MatrixRequest {
            Matrix = new int[][] {
                new int[]{11,2,4},
                new int[]{4,5,6},
                new int[]{10,8,-12}
            }
        };
        var result = controller.DiagonalDifference(req) as OkObjectResult;
        Assert.NotNull(result);
        var json = JObject.FromObject(result.Value);
        Assert.Equal(15, (int)json["difference"]);
    }

    [Fact]
    public void Matrix_DiagonalDifference_2x2()
    {
        var controller = new MatrixController();
        var req = new MatrixRequest {
            Matrix = new int[][] {
                new int[]{1,2},
                new int[]{3,4}
            }
        };
        var result = controller.DiagonalDifference(req) as OkObjectResult;
        Assert.NotNull(result);
        var json = JObject.FromObject(result.Value);
        // primary diagonal = 1 + 4 = 5, secondary = 2 + 3 = 5, difference = 0
        Assert.Equal(0, (int)json["difference"]);
    }
}
