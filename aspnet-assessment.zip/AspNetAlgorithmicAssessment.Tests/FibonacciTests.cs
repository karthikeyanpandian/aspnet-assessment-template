using Xunit;
using AspNetAlgorithmicAssessment.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

public class FibonacciTests
{
    [Theory]
    [InlineData(1, 0)]
    [InlineData(2, 1)]
    [InlineData(6, 12)]
    [InlineData(10, 88)]
    public void FibonacciSum_ReturnsExpected(int n, int expectedSum)
    {
        var controller = new FibonacciController();
        var result = controller.GetFibonacciSum(n) as OkObjectResult;
        Assert.NotNull(result);
        var json = JObject.FromObject(result.Value);
        Assert.Equal(expectedSum, (int)json["sum"]);
    }
}
